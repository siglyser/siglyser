# SigLyser
The signal processing application

## Project Log
April 2024:
Create the siglyser library after creating the base code in 2018.